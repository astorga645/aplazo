package com.aplazo.r2d2.payment.quote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsAplazoPaymentQuoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
